<?php

declare(strict_types=1);

namespace CoffeePOS\Admin;

use CoffeePOS\Core\Environment;
use CoffeePOS\Infrastructure\Database\Migrator;
use CoffeePOS\POS\Router;
use CoffeePOS\Support\Capabilities;

final class AdminBootstrap
{
    public function __construct(?Environment $environment = null, ?Migrator $migrator = null)
    {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'registerMenu']);
    }

    public function registerMenu(): void
    {
        add_submenu_page(
            'woocommerce',
            __('CoffeePOS', 'coffeepos'),
            __('CoffeePOS', 'coffeepos'),
            Capabilities::MANAGE_SETTINGS,
            'coffeepos',
            [$this, 'renderPage']
        );
    }

    public function renderPage(): void
    {
        if (! current_user_can(Capabilities::MANAGE_SETTINGS)) {
            wp_die(
                esc_html__('You are not allowed to manage CoffeePOS settings.', 'coffeepos'),
                esc_html__('Forbidden', 'coffeepos'),
                ['response' => 403]
            );
        }

        $posUrl = Router::routeUrl();
        $cashierUrl = Router::routeUrl('cashier');
        $settingsUrl = Router::routeUrl('settings');
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('CoffeePOS', 'coffeepos'); ?></h1>
            <p><?php esc_html_e('Use this page to find your point-of-sale address after installing CoffeePOS.', 'coffeepos'); ?></p>

            <div class="card">
                <h2><?php esc_html_e('Open your POS', 'coffeepos'); ?></h2>
                <p><?php esc_html_e('Share or bookmark this address for staff. CoffeePOS will sign them in and take them to a screen allowed by their role.', 'coffeepos'); ?></p>
                <p>
                    <label for="coffeepos-url"><strong><?php esc_html_e('POS address', 'coffeepos'); ?></strong></label><br>
                    <input id="coffeepos-url" class="regular-text code" type="url" value="<?php echo esc_attr($posUrl); ?>" readonly onclick="this.select();">
                </p>
                <p>
                    <a class="button button-primary" href="<?php echo esc_url($posUrl); ?>" target="_blank" rel="noopener noreferrer">
                        <?php esc_html_e('Open POS', 'coffeepos'); ?>
                        <span class="screen-reader-text"><?php esc_html_e('(opens in a new tab)', 'coffeepos'); ?></span>
                    </a>
                    <a class="button" href="<?php echo esc_url($cashierUrl); ?>" target="_blank" rel="noopener noreferrer">
                        <?php esc_html_e('Open Cashier', 'coffeepos'); ?>
                        <span class="screen-reader-text"><?php esc_html_e('(opens in a new tab)', 'coffeepos'); ?></span>
                    </a>
                </p>
            </div>

            <div class="card">
                <h2><?php esc_html_e('CoffeePOS settings', 'coffeepos'); ?></h2>
                <p><?php esc_html_e('Store, sales, payment, receipt, appearance, and operating settings are managed in the protected POS interface.', 'coffeepos'); ?></p>
                <p>
                    <a class="button" href="<?php echo esc_url($settingsUrl); ?>" target="_blank" rel="noopener noreferrer">
                        <?php esc_html_e('Manage CoffeePOS settings', 'coffeepos'); ?>
                        <span class="screen-reader-text"><?php esc_html_e('(opens in a new tab)', 'coffeepos'); ?></span>
                    </a>
                </p>
            </div>
        </div>
        <?php
    }
}
