<?php

declare(strict_types=1);

namespace CoffeePOS\Application\Error;

final class Phase01ErrorCodes
{
    public const INVALID_PRODUCT = 'invalid_product';

    public const INVALID_VARIATION = 'invalid_variation';

    public const VARIATION_NOT_FOUND = 'variation_not_found';

    public const INVALID_QUANTITY = 'invalid_quantity';

    public const OUT_OF_STOCK = 'out_of_stock';

    public const INVALID_STOCK_ADJUSTMENT = 'invalid_stock_adjustment';

    public const INVALID_HELD_CART = 'invalid_held_cart';

    public const HELD_CART_NOT_FOUND = 'held_cart_not_found';

    public const HELD_CART_STATE_CONFLICT = 'held_cart_state_conflict';

    public const HELD_CART_WRITE_FAILED = 'held_cart_write_failed';

    public const INVALID_ORDER_TYPE = 'invalid_order_type';

    public const TABLE_REQUIRED = 'table_required';

    public const TABLE_NOT_ALLOWED = 'table_not_allowed';

    public const CUSTOMER_NOT_FOUND = 'customer_not_found';

    public const INVALID_CUSTOMER_PHONE = 'invalid_customer_phone';

    public const CUSTOMER_LOOKUP_FAILED = 'customer_lookup_failed';

    public const CUSTOMER_PHONE_AMBIGUOUS = 'customer_phone_ambiguous';

    public const CUSTOMER_PHONE_EXISTS = 'customer_phone_exists';

    public const INVALID_CUSTOMER_NAME = 'invalid_customer_name';

    public const INVALID_CUSTOMER_EMAIL = 'invalid_customer_email';

    public const CUSTOMER_CREATE_FAILED = 'customer_create_failed';

    public const CUSTOMER_CREATION_LOCKED = 'customer_creation_locked';

    public const IDEMPOTENCY_KEY_REUSED = 'idempotency_key_reused';

    public const INVALID_CUSTOMER = 'invalid_customer';

    public const INVALID_TABLE = 'invalid_table';

    public const INVALID_COUPON = 'invalid_coupon';

    public const INVALID_CONFIGURATION = 'invalid_configuration';

    public const INVALID_CART = 'invalid_cart';
    public const INVALID_ORDER_NOTE = 'invalid_order_note';

    public const CART_SESSION_NOT_FOUND = 'cart_session_not_found';

    public const CART_REVISION_CONFLICT = 'cart_revision_conflict';

    public const EMPTY_CART = 'empty_cart';
    public const COUPON_NOT_APPLICABLE = 'coupon_not_applicable';
    public const INVALID_PAYMENT = 'invalid_payment';
    public const INSUFFICIENT_CASH = 'insufficient_cash';
    public const ORDER_CREATION_FAILED = 'order_creation_failed';
    public const PAYMENT_FAILED = 'payment_failed';
    public const PAYMENT_PENDING = 'payment_pending';
    public const PAYMENT_PROVIDER_UNAVAILABLE = 'payment_provider_unavailable';
    public const PAYMENT_VERIFICATION_FAILED = 'payment_verification_failed';
    public const INVALID_ORDER_STATE = 'invalid_order_state';
    public const ORDER_NOT_FOUND = 'order_not_found';
    public const DUPLICATE_OPERATION_CONFLICT = 'duplicate_operation_conflict';
    public const ORDER_STATE_CONFLICT = 'order_state_conflict';

    public const SHIFT_REQUIRED = 'shift_required';
    public const SHIFT_ALREADY_OPEN = 'shift_already_open';
    public const SHIFT_NOT_FOUND = 'shift_not_found';
    public const SHIFT_STATE_CONFLICT = 'shift_state_conflict';
    public const SHIFT_WRITE_FAILED = 'shift_write_failed';
    public const INVALID_SHIFT_AMOUNT = 'invalid_shift_amount';
    public const INVALID_SHIFT_NOTE = 'invalid_shift_note';

    public const INVALID_ORDER_FILTER = 'invalid_order_filter';
    public const INVALID_REFUND = 'invalid_refund';
    public const REFUND_FAILED = 'refund_failed';
    public const REORDER_FAILED = 'reorder_failed';

    public const INVALID_REPORT_RANGE = 'invalid_report_range';
    public const REPORT_RANGE_TOO_LARGE = 'report_range_too_large';
    public const REPORT_QUERY_FAILED = 'report_query_failed';
    public const REPORT_EXPORT_FAILED = 'report_export_failed';
    public const REPORT_EXPORT_UNAVAILABLE = 'report_export_unavailable';
}
