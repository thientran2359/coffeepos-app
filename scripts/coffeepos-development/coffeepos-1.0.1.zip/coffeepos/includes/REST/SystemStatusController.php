<?php

declare(strict_types=1);

namespace CoffeePOS\REST;

use CoffeePOS\Core\Environment;
use CoffeePOS\Infrastructure\Database\Migrator;
use CoffeePOS\Infrastructure\Database\Schema;
use CoffeePOS\Infrastructure\Settings\Settings;
use CoffeePOS\POS\Router;
use CoffeePOS\Support\ErrorFactory;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

final class SystemStatusController
{
    public const SCHEMA_VERSION = 1;

    public const OPTION_MACHINE_TOKEN_HASH = 'coffeepos_desktop_machine_token_sha256';

    private const MACHINE_TOKEN_HEADER = 'X-CoffeePOS-Machine-Token';

    public function register(string $namespace): void
    {
        register_rest_route($namespace, '/system/status', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [$this, 'status'],
                'permission_callback' => [$this, 'permissionCheck'],
            ],
        ]);
    }

    public function permissionCheck(WP_REST_Request $request)
    {
        $storedHash = strtolower(trim((string) get_option(self::OPTION_MACHINE_TOKEN_HASH, '')));
        $token = trim((string) $request->get_header(self::MACHINE_TOKEN_HEADER));

        if (
            strlen($storedHash) !== 64
            || ! ctype_xdigit($storedHash)
            || strlen($token) !== 64
            || ! ctype_xdigit($token)
        ) {
            return ErrorFactory::restError(
                'coffeepos_machine_auth_required',
                __('A valid CoffeePOS machine credential is required.', 'coffeepos'),
                401
            );
        }

        $actualHash = hash('sha256', strtolower($token));
        if (! hash_equals($storedHash, $actualHash)) {
            return ErrorFactory::restError(
                'coffeepos_machine_auth_required',
                __('A valid CoffeePOS machine credential is required.', 'coffeepos'),
                401
            );
        }

        return true;
    }

    public function status(WP_REST_Request $request): WP_REST_Response
    {
        $environment = new Environment();
        $wordpressReady = function_exists('get_bloginfo') && get_bloginfo('version') !== '';
        $woocommerceReady = $environment->isWooCommerceAvailable()
            && $environment->wooCommerceVersion() !== ''
            && $environment->isWooCommerceVersionSupported();
        $coffeeposReady = defined('COFFEEPOS_VERSION')
            && COFFEEPOS_VERSION !== ''
            && (string) get_option('coffeepos_installed_version', '') === COFFEEPOS_VERSION;
        $databaseReady = $this->databaseReady();
        $healthy = $wordpressReady && $woocommerceReady && $coffeeposReady && $databaseReady;

        $posPath = (string) wp_parse_url(Router::routeUrl(), PHP_URL_PATH);
        if ($posPath === '' || $posPath[0] !== '/') {
            $posPath = '/' . trim(Settings::getPosBaseSlug(), '/') . '/';
        }
        if (substr($posPath, -1) !== '/') {
            $posPath .= '/';
        }

        return new WP_REST_Response([
            'schema_version' => self::SCHEMA_VERSION,
            'status' => $healthy ? 'healthy' : 'degraded',
            'wordpress' => $wordpressReady,
            'woocommerce' => $woocommerceReady,
            'coffeepos' => $coffeeposReady,
            'database' => $databaseReady,
            'versions' => [
                'wordpress' => function_exists('get_bloginfo') ? (string) get_bloginfo('version') : '',
                'woocommerce' => $environment->wooCommerceVersion(),
                'coffeepos' => defined('COFFEEPOS_VERSION') ? (string) COFFEEPOS_VERSION : '',
                'coffeepos_schema' => Migrator::SCHEMA_VERSION,
            ],
            'store' => [
                'name' => Settings::getStoreName(),
            ],
            'pos_path' => $posPath,
        ], $healthy ? 200 : 503);
    }

    private function databaseReady(): bool
    {
        global $wpdb;

        if (! isset($wpdb) || ! is_object($wpdb) || ! isset($wpdb->dbh) || ! $wpdb->dbh) {
            return false;
        }
        if ((string) get_option(Migrator::OPTION_DB_VERSION, '') !== Migrator::SCHEMA_VERSION) {
            return false;
        }

        foreach (Schema::tableNames($wpdb->prefix) as $tableName) {
            $found = $wpdb->get_var(
                $wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($tableName))
            );
            if ($found !== $tableName) {
                return false;
            }
        }

        return true;
    }
}
