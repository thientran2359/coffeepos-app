<?php

declare(strict_types=1);

namespace CoffeePOS\Core;

use CoffeePOS\Admin\AdminBootstrap;
use CoffeePOS\Infrastructure\Assets\AssetLoader;
use CoffeePOS\Infrastructure\Database\Migrator;
use CoffeePOS\Infrastructure\Settings\Settings;
use CoffeePOS\POS\Router;
use CoffeePOS\POS\MemberPortalRouter;
use CoffeePOS\REST\RouteRegistrar;
use CoffeePOS\REST\SystemStatusController;
use CoffeePOS\Support\Capabilities;

final class Bootstrap
{
    private Environment $environment;

    private Settings $settings;

    private Migrator $migrator;

    private RouteRegistrar $routeRegistrar;

    private SystemStatusController $systemStatusController;

    private Router $router;

    private AssetLoader $assetLoader;

    private MemberPortalRouter $memberPortalRouter;

    private AdminBootstrap $adminBootstrap;

    public function __construct(
        ?Environment $environment = null,
        ?Settings $settings = null,
        ?Migrator $migrator = null,
        ?RouteRegistrar $routeRegistrar = null,
        ?Router $router = null,
        ?AssetLoader $assetLoader = null,
        ?AdminBootstrap $adminBootstrap = null,
        ?MemberPortalRouter $memberPortalRouter = null,
        ?SystemStatusController $systemStatusController = null
    ) {
        $this->environment = $environment ?? new Environment();
        $this->settings = $settings ?? new Settings();
        $this->migrator = $migrator ?? new Migrator();
        $this->routeRegistrar = $routeRegistrar ?? new RouteRegistrar();
        $this->systemStatusController = $systemStatusController ?? new SystemStatusController();
        $this->router = $router ?? new Router();
        $this->assetLoader = $assetLoader ?? new AssetLoader();
        $this->adminBootstrap = $adminBootstrap ?? new AdminBootstrap($this->environment, $this->migrator);
        $this->memberPortalRouter = $memberPortalRouter ?? new MemberPortalRouter();
    }

    public function run(): void
    {
        if (! $this->environment->isWordPressLoaded()) {
            return;
        }

        if (! $this->environment->isPhpVersionSupported()) {
            $this->notice(
                sprintf(
                    /* translators: %s: minimum PHP version. */
                    __('CoffeePOS requires PHP %s or higher.', 'coffeepos'),
                    $this->environment->minimumPhpVersion()
                )
            );

            return;
        }

        Settings::ensureDefaults();
        $this->settings->register();
        $this->adminBootstrap->register();
        add_action('rest_api_init', function (): void {
            $this->systemStatusController->register(RouteRegistrar::NAMESPACE);
        });

        if (! $this->environment->isWooCommerceAvailable()) {
            $this->notice(__('CoffeePOS requires WooCommerce to be installed and active.', 'coffeepos'));

            return;
        }

        if (! $this->environment->isWooCommerceVersionSupported()) {
            $this->notice(
                sprintf(
                    /* translators: %s: minimum WooCommerce version. */
                    __('CoffeePOS requires WooCommerce %s or higher.', 'coffeepos'),
                    $this->environment->minimumWooCommerceVersion()
                )
            );

            return;
        }

        add_action('init', [Capabilities::class, 'register'], 5);
        add_action('init', [$this->migrator, 'maybeMigrate'], 6);

        $this->routeRegistrar->register();
        add_filter('woocommerce_coupon_is_valid', [\CoffeePOS\Integration\WooCommerce\WooCommerceMembershipProvider::class, 'validateWooCoupon'], 20, 3);
        $this->router->register();
        $this->memberPortalRouter->register();
        $this->assetLoader->register();
    }

    private function notice(string $message): void
    {
        add_action('admin_notices', static function () use ($message): void {
            if (! current_user_can('activate_plugins')) {
                return;
            }

            echo '<div class="notice notice-error"><p>';
            echo esc_html($message);
            echo '</p></div>';
        });
    }
}
